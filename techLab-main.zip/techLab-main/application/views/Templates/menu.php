<div class="sidebar">
    <div class="list-group pe-2">
        <a href="#requisitos" class="list-group-item list-group-item-action">Requisitos para solicitar un préstamo</a>
         <a href="#procedimiento" class="list-group-item list-group-item-action">Procedimiento para solicitar un préstamo</a>
        <a href="#responsabilidades" class="list-group-item list-group-item-action">Responsabilidades del estudiante durante el préstamo</a>
        <a href="#disponibilidad" class="list-group-item list-group-item-action">Disponibilidad de equipos y horarios de préstamo</a>
        <a href="#normas" class="list-group-item list-group-item-action">Normas y políticas de uso del laboratorio</a>
        <a href="#contacto" class="list-group-item list-group-item-action">Contacto y preguntas frecuentes</a>
    </div>

    <hr>
</div>